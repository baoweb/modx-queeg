<?php
$_lang['setting_queeg.id'] = 'Show document ID';

$_lang['setting_queeg.published'] = 'Published';
$_lang['setting_queeg.published_desc'] = 'Show "published" status output';

$_lang['setting_queeg.editedon'] = 'Edited on';
$_lang['setting_queeg.editedon_desc'] = 'Show "Edited on" output';

$_lang['setting_queeg.editedby'] = 'Edited by';
$_lang['setting_queeg.editedby_desc'] = 'Show "published by" output';


$_lang['setting_queeg.date_format'] = 'Date Format';
$_lang['setting_queeg.date_format_desc'] = 'The format string, in PHP date() format, for the dates represented in the manager.';

$_lang['setting_queeg.custom_fields'] = 'Custom Fields (comma separated)';
$_lang['setting_queeg.custom_fields_desc'] = 'You can define comma separated list of additional fields (e.g.: pagetitle, alias)';