<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 Baoweb

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '# MODX Queeg
Queeg is a simple MODX Extra that provides a **one click** access to MODX Resources from a website to its manager.

More info: https://github.com/baoweb/modx-queeg',
    'changelog' => 'Changelog for Queeg.

Queeg 1.2.4 pl
==============
* Fix PHP warnings for undefined variables

Queeg 1.2.3 pl
==============
* Fix fatal error when user doesn\'t exist (probably when user was removed)

Queeg 1.2.2 pl
==============
* Fix php notice when user settings are not set

Queeg 1.2.1 pl
==============
* Fix potentially flooding Error log

Queeg 1.2.0 pl
==============
+ Add custom date format
+ Add choice for completely enable / disable plugin
+ Fix loading system settings 
+ Fix loading lexicon translation
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1122229c3096ed27b7c610e399afcde4',
      'native_key' => 'queeg',
      'filename' => 'modNamespace/fc2d4279b1c5bdff4b85ccc942ed5bcb.vehicle',
      'namespace' => 'queeg',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ae12108cb67582f8e7cf26dd693f9a3',
      'native_key' => 'queeg.published',
      'filename' => 'modSystemSetting/0e3eef471b3dc07848c099428e79c24b.vehicle',
      'namespace' => 'queeg',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70c93af5cd3c4d9b9522c28ba47bd0ba',
      'native_key' => 'queeg.editedon',
      'filename' => 'modSystemSetting/ae6dddbcd86dce95cb300ac4e46e3e57.vehicle',
      'namespace' => 'queeg',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca746f2934f8c7713ada79b3bb191f75',
      'native_key' => 'queeg.editedby',
      'filename' => 'modSystemSetting/f0f89e8887b7e7fd38185b6dc8af2889.vehicle',
      'namespace' => 'queeg',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd3fb108cb1591c98f243cd061701931',
      'native_key' => 'queeg.date_format',
      'filename' => 'modSystemSetting/74237038c88790f77697ca6925cda763.vehicle',
      'namespace' => 'queeg',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef1f245030aa888cc226d6c483c8a5d3',
      'native_key' => 'queeg.custom_fields',
      'filename' => 'modSystemSetting/007fdd86603409bd70398a16768fd14c.vehicle',
      'namespace' => 'queeg',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3d61210db24882a0f5a03419c9123a6',
      'native_key' => 'queeg.active',
      'filename' => 'modSystemSetting/7779c37bc94c0b34cd56c5c4dfa96f3a.vehicle',
      'namespace' => 'queeg',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'df03d690b9e4e9683fab02058c8584d0',
      'native_key' => NULL,
      'filename' => 'modCategory/a64698b951bd28f92133938b415b3022.vehicle',
      'namespace' => 'queeg',
    ),
  ),
);