<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 Baoweb

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '# MODX Queeg
Queeg is a simple MODX Extra that provides a **one click** access to MODX Resources from a website to its manager.

More info: https://github.com/baoweb/modx-queeg',
    'changelog' => 'Changelog for Queeg.

Queeg 1.2.2 pl
==============
* Fix fatal error when user doesn\'t exist

Queeg 1.2.2 pl
==============
* Fix php notice when user settings are not set

Queeg 1.2.1 pl
==============
* Fix potentially flooding Error log

Queeg 1.2.0 pl
==============
+ Add custom date format
+ Add choice for completely enable / disable plugin
+ Fix loading system settings 
+ Fix loading lexicon translation
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9c9663438bea375a6c47f70acfbd1997',
      'native_key' => 'queeg',
      'filename' => 'modNamespace/cb4a24f782fa903e9e102b3a2ddc4124.vehicle',
      'namespace' => 'queeg',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6402c8c21527e169391337563af0b9f',
      'native_key' => 'queeg.published',
      'filename' => 'modSystemSetting/5605a952277860f4d7f9fce85223327a.vehicle',
      'namespace' => 'queeg',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f3b4241fb7f810d61934ce1d38b44a3',
      'native_key' => 'queeg.editedon',
      'filename' => 'modSystemSetting/ffaeb67054a6a79a69b3029e1fd04668.vehicle',
      'namespace' => 'queeg',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e717ab202f4b4682f5e3589108b592a6',
      'native_key' => 'queeg.editedby',
      'filename' => 'modSystemSetting/b16c693527f4947cd53c4d4c533a300e.vehicle',
      'namespace' => 'queeg',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49ded6346e3f21796a7794dc354232ef',
      'native_key' => 'queeg.date_format',
      'filename' => 'modSystemSetting/95c1c656e78c77e465452dd501106bc6.vehicle',
      'namespace' => 'queeg',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69298326bd7c0afddd48331017c8aca6',
      'native_key' => 'queeg.custom_fields',
      'filename' => 'modSystemSetting/1131f146df0ab4b85b0ec70bcef83daa.vehicle',
      'namespace' => 'queeg',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd53a28eb382ff96a3f6a382597636f7',
      'native_key' => 'queeg.active',
      'filename' => 'modSystemSetting/6edab6379bb4a2ef1517533271ee7ec5.vehicle',
      'namespace' => 'queeg',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b2e7d01ec0fc4e0d57b2d4ae2b868971',
      'native_key' => NULL,
      'filename' => 'modCategory/3c514fc26506f3dd53019fdce0200a25.vehicle',
      'namespace' => 'queeg',
    ),
  ),
);