# MODX Queeg
Queeg is a simple MODX Extra that provides a **one click** access to MODX Resources from a website to its manager.

More info: https://github.com/baoweb/modx-queeg