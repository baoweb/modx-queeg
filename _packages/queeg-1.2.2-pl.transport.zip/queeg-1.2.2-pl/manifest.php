<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 Baoweb

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '# MODX Queeg
Queeg is a simple MODX Extra that provides a **one click** access to MODX Resources from a website to its manager.

More info: https://github.com/baoweb/modx-queeg',
    'changelog' => 'Changelog for Queeg.

Queeg 1.2.2 pl
==============
* Fix php notice when user settings are not set

Queeg 1.2.1 pl
==============
* Fix potentially flooding Error log

Queeg 1.2.0 pl
==============
+ Add custom date format
+ Add choice for completely enable / disable plugin
+ Fix loading system settings 
+ Fix loading lexicon translation
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ad39039061b63e8af72913fecc8c9107',
      'native_key' => 'queeg',
      'filename' => 'modNamespace/00bf42eca05860508c28de8fd39e1ad6.vehicle',
      'namespace' => 'queeg',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '501c5212d0a1b3253e7a98ea49a2f1b9',
      'native_key' => 'queeg.published',
      'filename' => 'modSystemSetting/2bd27849d1ae5a1d64883dceea758f46.vehicle',
      'namespace' => 'queeg',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70516b1cc01b6d4cf60b64c743c3b3fd',
      'native_key' => 'queeg.editedon',
      'filename' => 'modSystemSetting/1b31f8fd3b497d65f712294e98c7f866.vehicle',
      'namespace' => 'queeg',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bf7267c070bc1565d39986bb616d433',
      'native_key' => 'queeg.editedby',
      'filename' => 'modSystemSetting/a15907ca2598ff0ae1519527bf4ee647.vehicle',
      'namespace' => 'queeg',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54a8b5fbe216fe15c5126c3379891190',
      'native_key' => 'queeg.date_format',
      'filename' => 'modSystemSetting/c97d6d7c81c15092db981e8cd6cf4311.vehicle',
      'namespace' => 'queeg',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f5ea73e95507cb564dfccc4348ff49d',
      'native_key' => 'queeg.custom_fields',
      'filename' => 'modSystemSetting/ccaf868b2592991df750a91082927a38.vehicle',
      'namespace' => 'queeg',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7e872e21f1986b6ffa0bb5eccffdb79',
      'native_key' => 'queeg.active',
      'filename' => 'modSystemSetting/c8ca345f66201c8d4e69807b7ee12a2b.vehicle',
      'namespace' => 'queeg',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5e312174781951e2197047c4581cb6bd',
      'native_key' => NULL,
      'filename' => 'modCategory/bcec20584f46ab847c5f424cb42b0898.vehicle',
      'namespace' => 'queeg',
    ),
  ),
);