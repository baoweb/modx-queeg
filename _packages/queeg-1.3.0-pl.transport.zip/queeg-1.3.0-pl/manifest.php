<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 Baoweb

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '# MODX Queeg
Queeg is a simple MODX Extra that provides a **one click** access to MODX Resources from a website to its manager.

More info: https://github.com/baoweb/modx-queeg',
    'changelog' => 'Changelog for Queeg.

Queeg 1.3.0 pl
==============
* Add Timing tags. Now you can see Query Time, Query Count and Total Time.  (Of course you can turn it off in System Settings).
Thanks to Mikhail (mishantrop)

Queeg 1.2.4 pl
==============
* Fix PHP warnings for undefined variables

Queeg 1.2.3 pl
==============
* Fix fatal error when user doesn\'t exist (probably when user was removed)

Queeg 1.2.2 pl
==============
* Fix php notice when user settings are not set

Queeg 1.2.1 pl
==============
* Fix potentially flooding Error log

Queeg 1.2.0 pl
==============
+ Add custom date format
+ Add choice for completely enable / disable plugin
+ Fix loading system settings
+ Fix loading lexicon translation
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1d195b676a7bf87c4b560e3c4b6fc602',
      'native_key' => 'queeg',
      'filename' => 'modNamespace/f0448a7d140707c3315c376c1f6b61d4.vehicle',
      'namespace' => 'queeg',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac3712e86e61154dce8fcc48c4cccd28',
      'native_key' => 'queeg.published',
      'filename' => 'modSystemSetting/bb923579f7bf7ca0fb30005c6fbc699a.vehicle',
      'namespace' => 'queeg',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dee2a88c917b98ea713e70ea3962e4f6',
      'native_key' => 'queeg.timing',
      'filename' => 'modSystemSetting/2d6d2c27e5fadd5c9a65f964f1f0b145.vehicle',
      'namespace' => 'queeg',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ab7bfa16b8ccbcba80ecb95d592561a',
      'native_key' => 'queeg.editedon',
      'filename' => 'modSystemSetting/db2f57b719e3e179205d2993ac1c740f.vehicle',
      'namespace' => 'queeg',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03bd61c101f1e74c43ebaec6943708f7',
      'native_key' => 'queeg.editedby',
      'filename' => 'modSystemSetting/205ec05999e70175313a324ac5517ffd.vehicle',
      'namespace' => 'queeg',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4bf5d53e980cafd006e80a8ddae314f',
      'native_key' => 'queeg.date_format',
      'filename' => 'modSystemSetting/bbcad7dde65ffcff8376551546fc1fa1.vehicle',
      'namespace' => 'queeg',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fa5cf7022c76f9e56aff1389c55fd66',
      'native_key' => 'queeg.custom_fields',
      'filename' => 'modSystemSetting/988869e177f1bf62d5231d1d45e5f346.vehicle',
      'namespace' => 'queeg',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2cb2fdaa4af34b666bd5cd482c607cd',
      'native_key' => 'queeg.active',
      'filename' => 'modSystemSetting/418001dd50b6b3e3edb9b099caf31564.vehicle',
      'namespace' => 'queeg',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd20efda6acb206aabdaf7775137ef4b0',
      'native_key' => NULL,
      'filename' => 'modCategory/eb9339b919f14128847e8b6525a66496.vehicle',
      'namespace' => 'queeg',
    ),
  ),
);